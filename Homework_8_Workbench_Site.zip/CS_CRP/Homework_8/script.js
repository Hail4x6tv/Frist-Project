const panelLayer = document.getElementById('panelLayer');
const panelTitle = document.getElementById('panelTitle');
const panelKicker = document.getElementById('panelKicker');
const panelContent = document.getElementById('panelContent');
const toast = document.getElementById('toast');
const soundToggle = document.getElementById('soundToggle');
let lastFocusedElement = null;
let audioContext = null;
let soundEnabled = false;

const panels = {
  projects: {
    kicker: 'WORKSHOP FILE / 001 — SELECTED WORK',
    title: 'The Project Shelf',
    html: `
      <p>A collection of things I have made, explored, or want to improve. Replace these sample entries with your real school, coding, design, or personal projects.</p>
      <div class="panel-grid">
        <section class="file-card"><span class="file-tag">01 / WEB</span><h3>Interactive Workbench</h3><p>This portfolio itself: an experiment in turning a website into a place you can explore.</p></section>
        <section class="file-card"><span class="file-tag">02 / DESIGN</span><h3>Creative Experiments</h3><p>Add a poster, visual design, or image-editing project here. Explain what you learned.</p></section>
        <section class="file-card"><span class="file-tag">03 / CODE</span><h3>Small Builds</h3><p>Show a useful program, school assignment, or coding challenge you are proud of.</p></section>
        <section class="file-card"><span class="file-tag">04 / NEXT</span><h3>Work in Progress</h3><p>Keep a space for experiments that are not finished yet. Progress is part of making.</p></section>
      </div>
      <p class="edit-reminder">YOUR EDIT: Change the titles and descriptions in <strong>script.js</strong> so they describe your actual work.</p>`
  },
  about: {
    kicker: 'WORKSHOP FILE / 002 — MAKER PROFILE',
    title: 'A Little About Me',
    html: `
      <p>Hello! I am <strong>[Your Name]</strong> — a student who enjoys learning how things work and turning ideas into something real.</p>
      <p>This desk represents the way I like to work: experiment, make mistakes, figure things out, and keep improving. I am interested in <strong>[your interests: technology, design, coding, photography, etc.]</strong>.</p>
      <h3>Milestones & achievements</h3>
      <dl class="detail-list"><dt>Achievement 01</dt><dd>[Add an award, school milestone, or personal achievement]</dd><dt>Achievement 02</dt><dd>[Add a project or skill you have developed]</dd><dt>Learning now</dt><dd>[Add the subject or skill you are currently learning]</dd></dl>
      <p class="edit-reminder">YOUR EDIT: Replace <strong>assets/profile-placeholder.svg</strong> with your own portrait and update this text in <strong>script.js</strong>.</p>`
  },
  future: {
    kicker: 'WORKSHOP FILE / 003 — FUTURE PLANS',
    title: 'Things I Want to Build',
    html: `
      <p>The best ideas start as rough sketches. This blueprint is a reminder of what I want to learn, create, and contribute in the future.</p>
      <div class="panel-grid">
        <section class="file-card"><span class="file-tag">SHORT TERM</span><h3>Build stronger skills</h3><p>Become more confident with programming, problem-solving, and creative tools.</p></section>
        <section class="file-card"><span class="file-tag">MID TERM</span><h3>Make useful projects</h3><p>Create websites and digital experiences that solve real problems for people.</p></section>
        <section class="file-card"><span class="file-tag">LONG TERM</span><h3>Turn ideas into products</h3><p>Work on original ideas, collaborate with others, and keep learning through making.</p></section>
        <section class="file-card"><span class="file-tag">PERSONAL RULE</span><h3>Stay curious</h3><p>Do not stop experimenting just because the first attempt does not work.</p></section>
      </div>
      <p class="edit-reminder">YOUR EDIT: Make these aspirations specific to your own goals and interests.</p>`
  },
  concept: {
    kicker: 'WORKSHOP FILE / 004 — DESIGN NOTES',
    title: 'Why a Workbench?',
    html: `
      <p>This portfolio is designed as a maker's workbench, where projects, personal details, and future plans are represented by objects scattered across a desk.</p>
      <p>It is unconventional because visitors explore by clicking the objects themselves instead of following a standard header, navigation bar, or page layout. The desk is the navigation system, and every object opens a different part of the story.</p>
      <p class="edit-reminder">TIP: Keep this explanation on the website. It directly describes the concept and why the navigation is unconventional.</p>`
  }
};

function playTone(frequency = 520, duration = 0.07, type = 'sine') {
  if (!soundEnabled) return;
  try {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();
    oscillator.type = type;
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.045, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duration);
    oscillator.connect(gain);
    gain.connect(audioContext.destination);
    oscillator.start();
    oscillator.stop(audioContext.currentTime + duration);
  } catch (error) {
    // Audio is decorative; the site still works when browser audio is unavailable.
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('show'), 2300);
}

function openPanel(panelName, trigger) {
  const panel = panels[panelName];
  if (!panel) return;
  lastFocusedElement = trigger || document.activeElement;
  panelKicker.textContent = panel.kicker;
  panelTitle.textContent = panel.title;
  panelContent.innerHTML = panel.html;
  panelLayer.classList.add('is-open');
  panelLayer.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  panelLayer.querySelector('.panel-close').focus();
  playTone(620, 0.08);
}

function closePanel() {
  panelLayer.classList.remove('is-open');
  panelLayer.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  if (lastFocusedElement && typeof lastFocusedElement.focus === 'function') lastFocusedElement.focus();
}

document.querySelectorAll('[data-panel]').forEach((object) => {
  object.addEventListener('click', () => openPanel(object.dataset.panel, object));
  object.addEventListener('mouseenter', () => playTone(440, 0.035));
});

document.querySelectorAll('[data-close-panel]').forEach((element) => element.addEventListener('click', closePanel));
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && panelLayer.classList.contains('is-open')) closePanel();
  if (event.key === 'Tab' && panelLayer.classList.contains('is-open')) {
    const focusable = [...panelLayer.querySelectorAll('button, a[href], [tabindex]:not([tabindex="-1"])')];
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
});

// Clicking either Homework 7 object gives a short visual/audio cue; the real link remains a normal href.
document.querySelectorAll('.radio-object, .solder-object').forEach((link) => {
  link.addEventListener('click', () => {
    link.classList.add('tuning');
    playTone(760, 0.12, 'triangle');
    showToast('TUNING IN TO HOMEWORK 07…');
    window.setTimeout(() => link.classList.remove('tuning'), 550);
  });
});

soundToggle.addEventListener('click', () => {
  soundEnabled = !soundEnabled;
  soundToggle.setAttribute('aria-pressed', String(soundEnabled));
  soundToggle.querySelector('.sound-label').textContent = soundEnabled ? 'SOUND ON' : 'SOUND OFF';
  soundToggle.querySelector('.sound-icon').textContent = soundEnabled ? '♫' : '♪';
  if (soundEnabled) playTone(660, 0.1);
  showToast(soundEnabled ? 'WORKSHOP SOUNDS ENABLED' : 'WORKSHOP SOUNDS MUTED');
});

// Helpful first-visit hint without interrupting the experience.
window.setTimeout(() => showToast('START EXPLORING — CLICK THE OBJECTS'), 850);
