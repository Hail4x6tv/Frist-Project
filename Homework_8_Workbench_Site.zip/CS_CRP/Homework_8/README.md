# Homework 8 — The Maker's Workbench

A static HTML, CSS, and JavaScript portfolio designed as a top-down vintage maker's desk. There is no server, database, framework, or build step.

## Files

- `index.html` — the workbench scene and interactive objects
- `styles.css` — desk styling, responsive layout, and animations
- `script.js` — clickable panels, keyboard support, optional sound cues, and Homework 7 interactions
- `assets/profile-placeholder.svg` — temporary portrait artwork; replace it with your own photo before submitting

## Personalise before submitting

1. Replace `assets/profile-placeholder.svg` with your own portrait. The easiest option is to add your photo as `assets/profile-photo.jpg`, then change the image `src` in `index.html` to `assets/profile-photo.jpg`.
2. Open `script.js` and edit the sample text in the `panels` object: update your name, interests, projects, achievements, and aspirations.
3. Check the Homework 7 path in `index.html`. It is currently `../Homework_7/`, assuming your Homework 7 site is at `CS_CRP/Homework_7/index.html`.

## GitHub Pages deployment

The project is already arranged under `CS_CRP/Homework_8/` in the supplied ZIP. Copy that folder into the root of your existing `Heuser` repository, preserving the folder structure, then commit and push it.

If GitHub Pages is configured to publish from the repository root (or a branch root), open:

`https://YOUR-GITHUB-USERNAME.github.io/Heuser/CS_CRP/Homework_8/`

If your repository uses a different Pages publishing source, make sure the `CS_CRP/Homework_8/` folder is included in the selected source.

## Local testing

Open `index.html` in a browser. Internet access is only needed to load the optional Google Fonts; the site itself is static.
